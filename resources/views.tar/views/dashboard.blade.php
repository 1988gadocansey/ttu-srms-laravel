@extends('layouts.app')

 
@section('style')
  <!-- additional styles for plugins -->
        <!-- weather icons -->
        <link rel="stylesheet" href="public/assets/plugins/weather-icons/css/weather-icons.min.css" media="all">
        <!-- metrics graphics (charts) -->
        <link rel="stylesheet" href="public/assets/plugins/metrics-graphics/dist/metricsgraphics.css">
        <!-- chartist -->
        <link rel="stylesheet" href="public/assets/plugins/chartist/dist/chartist.min.css">
    
@endsection
 @section('content')
 <div class="md-card-content">

    @if(Session::has('success'))
            <div style="text-align: center" class="uk-alert uk-alert-success" data-uk-alert="">
                {!! Session::get('success') !!}
            </div>
 @endif


    @if (count($errors) > 0)


    <div class="uk-alert uk-alert-danger  uk-alert-close" style="background-color: red;color: white" data-uk-alert="">

        <ul>
            @foreach ($errors->all() as $error)
            <li>{!!$error  !!} </li>
            @endforeach
        </ul>
    </div>

    @endif


</div>
   
   @inject('sys', 'App\Http\Controllers\SystemController')
  
      
         <div class="uk-grid uk-grid-width-large-1-4 uk-grid-width-medium-1-2 uk-grid-medium uk-sortable ">
                 <div>
                    <div class="md-card">
                        <div class="md-card-content">
                            <div class="uk-float-right uk-margin-top uk-margin-small-right"><span class=""><i class="sidebar-menu-icon material-icons md-36">access_time</i></span></div>
                            <span class="uk-text-bold uk-text-small">Last Visit</span>
                            <h5 class="uk-margin-remove"><span class="uk-text-small uk-text-success"> {{$lastVisit}}</span></h5>
                        </div>
                    </div>
                </div>
                  @if( @Auth::user()->department=='top' || @Auth::user()->department=='Rector'  || @Auth::user()->department=='Tpmid' || @Auth::user()->department=='Tptop')
                <div>
                    <div class="md-card">
                        <div class="md-card-content">
                            <div class="uk-float-right uk-margin-top uk-margin-small-right"><span class=" "><i class="sidebar-menu-icon material-icons md-36">account_balance</i></span></div>
                            <span class="uk-text-muted uk-text-small">Owing - <span class="uk-text-bold uk-text-danger ">GH<?php echo $sys->formatMoney($sys->getOweTotalOverAll()); ?> </span></span><br/>
                            <span class="uk-text-muted uk-text-small">Paid - <span class="uk-text-bold uk-text-success ">GH <?php echo $sys->formatMoney($sys->getPaidTotalOverAll()); ?> </span></span>
                        </div>
                    </div>
                </div>
             <div>
                    <div class="md-card">
                        <div class="md-card-content">
                            <div class="uk-float-right uk-margin-top uk-margin-small-right"><span class=""><i class="sidebar-menu-icon material-icons md-36">event_note</i></span></div>
                            <span class="uk-text-muted uk-text-small">Total Students - <span class="uk-text-bold uk-text-primary ">{{$total}} </span></span><br/>
                            <span class="uk-text-muted uk-text-small">Registered - <span class="uk-text-bold uk-text-success ">{!!$totalRegistered!!} </span></span>
                        </div>
                    </div>
                </div>
             @endif
                <div>
                    <div class="md-card">
                        <div class="md-card-content">
                         <div class="uk-float-right uk-margin-top uk-margin-small-right"><span class=""><i class="sidebar-menu-icon material-icons md-36">event_note</i></span></div>
                            <span class="uk-text-muted uk-text-small">Academic Calender</span>
                            <h5 class="uk-margin-remove"><span class="uk-text-small uk-text-success "> Semester {{$sem}} : Year {{$year}}</span></h5>
                        </div>
                    </div>
                </div>
                  @if( @Auth::user()->role=='Lecturer' || @Auth::user()->role=='HOD')
             <div>
                    <div class="md-card">
                        <div class="md-card-content">
                         <div class="uk-float-right uk-margin-top uk-margin-small-right"><span class=""><i class="sidebar-menu-icon material-icons md-36">event_note</i></span></div>
                            <span class="uk-text-muted uk-text-small">Total Students</span>
                            <h5 class="uk-margin-remove"><span class="uk-text-small uk-text-success "> Students = {{$total}}  </span></h5>
                        </div>
                    </div>
                </div>
               <div>
                    <div class="md-card">
                        <div class="md-card-content">
                         <div class="uk-float-right uk-margin-top uk-margin-small-right"><span class=""><i class="sidebar-menu-icon material-icons md-36">event_note</i></span></div>
                            <span class="uk-text-muted uk-text-small">Class Size</span>
                            <h5 class="uk-margin-remove"><span class="uk-text-small uk-text-success "> Your Class Size = {{$register}}  </span></h5>
                        </div>
                    </div>
                </div>
                @endif
            </div>

           @if( @Auth::user()->role=='Lecturer' || @Auth::user()->role=='HOD' || @Auth::user()->department=='top' || @Auth::user()->department=='Rector' || @Auth::user()->department=='Tpmid' || @Auth::user()->department=='Tptop')
            <div class="uk-grid uk-grid-width-small-1-2 uk-grid-width-large-1-3 uk-grid-width-xlarge-1-5 uk-text-center uk-sortable sortable-handler" id="dashboard_sortable_cards" data-uk-sortable data-uk-grid-margin>
                      @if( @Auth::user()->role=='Support')
                <div>
                    <div class="md-card md-card-hover md-card-overlay">
                        <div class="md-card-content">
                            <a target="_" href='{{url("http://portal.tpolyonline/course_registration")}}'>  <img src="{{url('public/assets/img/dashboard/registration.png')}}"/></a>
                        </div>
                        <div class="md-card-overlay-content">
                            <div class="uk-clearfix md-card-overlay-header">
                                <i class="md-icon material-icons md-card-overlay-toggler">&#xE5D4;</i>
                                <h3 class="uk-text-center uk-text-upper">
                                    REGISTER STUDENTS
                                </h3>
                            </div>
                           Click here to register students
                        </div>
                    </div>
                </div>
                      @endif
                 @if( @Auth::user()->department=='top' || @Auth::user()->department=='Rector' || @Auth::user()->department=='Tpmid' || @Auth::user()->department=='Tptop')
                <div>
                    <div class="md-card md-card-hover md-card-overlay">
                        <div class="md-card-content">
                            <a  href='{{url("/transcript")}}'>  <img src="{{url('public/assets/img/dashboard/transcript.png')}}"/></a>
                        </div>
                        <div class="md-card-overlay-content">
                            <div class="uk-clearfix md-card-overlay-header">
                                <i class="md-icon material-icons md-card-overlay-toggler">&#xE5D4;</i>
                                <h3 class="uk-text-center uk-text-upper">
                                    TRANSCRIPTS
                                </h3>
                            </div>
                            Print Official transcript for students after they have paid at the Accounts Office
                        </div>
                    </div>
                </div>
                 @endif
                    @if( @Auth::user()->department=='top' ||  @Auth::user()->role=='Lecturer' ||  @Auth::user()->role=='HOD' || @Auth::user()->department=='Rector' || @Auth::user()->department=='Tpmid' || @Auth::user()->department=='Tptop')
                <div>
                    <div class="md-card md-card-hover md-card-overlay">
                        <div class="md-card-content">
                            <a  href='{{url("/upload/marks")}}'>  <img src="{{url('public/assets/img/dashboard/results.png')}}"/></a>
                        </div>
                        <div class="md-card-overlay-content">
                            <div class="uk-clearfix md-card-overlay-header">
                                <i class="md-icon material-icons md-card-overlay-toggler">&#xE5D4;</i>
                                <h3 class="uk-text-center uk-text-upper">
                                   UPLOAD RESULTS
                                </h3>
                            </div>
                            <p>Upload semester results here. Only registered students results can be uploaded</p>
                            <button class="md-btn md-btn-primary">More</button>
                        </div>
                    </div>
                </div>
                    @endif
                 @if( @Auth::user()->department=='top' ||  @Auth::user()->role=='Lecturer' ||  @Auth::user()->role=='HOD' || @Auth::user()->department=='Rector' || @Auth::user()->department=='Tpmid' || @Auth::user()->department=='Tptop')
                
                <div>
                    <div class="md-card md-card-hover md-card-overlay">
                        <div class="md-card-content">
                            <a  href='{{url("/check/course")}}'>  <img src="{{url('public/assets/img/dashboard/uploadnotes.png')}}"/></a>
                        </div>
                        <div class="md-card-overlay-content uk-badge-success">
                            <div class="uk-clearfix md-card-overlay-header">
                                <i class="md-icon material-icons md-card-overlay-toggler">&#xE5D4;</i>
                                <h3 class="uk-text-center uk-text-upper uk-text-red">
                                  CLICK TO VERIFY YOUR COURSES MOUNTED FOR REGISTRATION
                                </h3>
                            </div>
                           Click to verify all mounted courses for your department for this semester
                        </div>
                    </div>
                </div>
                 @endif
                  @if( @Auth::user()->role=='Lecturer'  || @Auth::user()->role=='HOD')
                <div>
                     <div class="md-card md-card-hover md-card-overlay">
                        <div class="md-card-content">
                            <a  href='{{url("/registered_courses")}}'>  <img src="{{url('public/assets/img/dashboard/classlist.png')}}"/></a>
                        </div>
                        <div class="md-card-overlay-content">
                            <div class="uk-clearfix md-card-overlay-header">
                                <i class="md-icon material-icons md-card-overlay-toggler">&#xE5D4;</i>
                                <h3 class="uk-text-center uk-text-upper">
                                    CLASS LIST
                                </h3>
                            </div>
                           View registered students for your courses and enter marks
                        </div>
                    </div>
                </div>
                 
                  
                <div>
                     <div class="md-card md-card-hover md-card-overlay">
                        <div class="md-card-content">
                            <a  href='{{url("/transcript")}}'>  <img src="{{url('public/assets/img/dashboard/classgroup.png')}}"/></a>
                        </div>
                        <div class="md-card-overlay-content">
                            <div class="uk-clearfix md-card-overlay-header">
                                <i class="md-icon material-icons md-card-overlay-toggler">&#xE5D4;</i>
                                <h3 class="uk-text-center uk-text-upper">
                                   CLASS GROUPS
                                </h3>
                            </div>
                           View your class groups
                        </div>
                    </div>
                </div>
                  
                   @endif
                @endif
                <div>
                    <div class="md-card md-card-hover md-card-overlay">
                        <div class="md-card-content">
                            <a  href='{{url("http://www.ttu.edu.gh/webmail")}}'>  <img src="{{url('public/assets/img/dashboard/email.png')}}"/></a>
                        </div>
                        <div class="md-card-overlay-content">
                            <div class="uk-clearfix md-card-overlay-header">
                                <i class="md-icon material-icons md-card-overlay-toggler">&#xE5D4;</i>
                                <h3 class="uk-text-center uk-text-upper">
                                  STAFF EMAILS
                                </h3>
                            </div>
                           Click to go access your emails
                        </div>
                    </div>
                </div>
                
                   @if( @Auth::user()->department=='top' || @Auth::user()->department=='Tpmid'|| @Auth::user()->department=='Rector' || @Auth::user()->department=='Tptop')  
                        <div>
                            <div class="md-card md-card-hover md-card-overlay">
                                <div class="md-card-content">
                                    <div class="epc_chart" data-percent="37" data-bar-color="#607d8b">
                                        <span class="epc_chart_icon"><i class="material-icons">&#xE7FE;</i></span>
                                    </div>
                                </div>
                                <div class="md-card-overlay-content">
                                    <div class="uk-clearfix md-card-overlay-header">
                                        <i class="md-icon material-icons md-card-overlay-toggler">&#xE5D4;</i>
                                        <h3>
                                          CREATE USERS
                                        </h3>
                                    </div>
                                    Create a new user account
                                </div>
                            </div>
                        </div>
                   @endif
            </div> 
         
        
            <!-- tasks -->
            <div class="uk-grid" data-uk-grid-margin data-uk-grid-match="{target:'.md-card-content'}">
                <div class="uk-width-medium-1-2">
                    <div class="md-card">
                        <div class="md-card-content">
                            <div class="uk-overflow-container">
                                <table class="uk-table">
                                    <thead>
                                        <tr>
                                            <th class="uk-text-nowrap">Level</th>
                                            <th class="uk-text-nowrap">M</th>
                                            <th class="uk-text-nowrap">F</th>
                                            <th class="uk-text-nowrap">?</th>
                                            <th class="uk-text-nowrap">Total</th>
                                            <th class="uk-text-nowrap">Reg</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       
                                       <tr class="uk-table-middle">
                                            <td>Non Tertiary Level 100 </td>
                                            <td class=''><?php $am=$sys->getStudentsTotalOverAll('100NT')->Male; echo $am;?></td>
                                            <td class=''><?php $af=$sys->getStudentsTotalOverAll('100NT')->Female; echo $af;?></td>
                                            <td class=''><?php $au=$sys->getStudentsTotalOverAll('100NT')->Unknown; echo $au;?></td>
                                            <td class=''><?php $at=$sys->getStudentsTotalOverAll('100NT')->Total; echo $at;?></td>
                                            <td class=''><?php $ar=$sys->getStudentsTotalOverAll('100NT')->Reg; echo $ar;?></td>
                                        </tr>
                                        <tr class="uk-table-middle">
                                            <td>Non Tertiary Level 200</td>
                                            <td class=''><?php $bm=$sys->getStudentsTotalOverAll('200NT')->Male; echo $bm;?></td>
                                            <td class=''><?php $bf=$sys->getStudentsTotalOverAll('200NT')->Female; echo $bf;?></td>
                                            <td class=''><?php $bu=$sys->getStudentsTotalOverAll('200NT')->Unknown; echo $bu;?></td>
                                            <td class=''><?php $bt=$sys->getStudentsTotalOverAll('200NT')->Total; echo $bt;?></td>
                                            <td class=''><?php $br=$sys->getStudentsTotalOverAll('200NT')->Reg; echo $br;?></td>
                                        </tr>
                                        <tr class="uk-table-middle">
                                            <td>Level 100 HND</td>
                                            <td class=''><?php $cm=$sys->getStudentsTotalOverAll('100H')->Male; echo $cm;?></td>
                                            <td class=''><?php $cf=$sys->getStudentsTotalOverAll('100H')->Female; echo $cf;?></td>
                                            <td class=''><?php $cu=$sys->getStudentsTotalOverAll('100H')->Unknown; echo $cu;?></td>
                                            <td class=''><?php $ct=$sys->getStudentsTotalOverAll('100H')->Total; echo $ct;?></td>
                                            <td class=''><?php $cr=$sys->getStudentsTotalOverAll('100H')->Reg; echo $cr;?></td>
                                        </tr>
                                      <tr class="uk-table-middle">
                                            <td>Level 200 HND</td>
                                            <td class=''><?php $dm=$sys->getStudentsTotalOverAll('200H')->Male; echo $dm;?></td>
                                            <td class=''><?php $df=$sys->getStudentsTotalOverAll('200H')->Female; echo $df;?></td>
                                            <td class=''><?php $du=$sys->getStudentsTotalOverAll('200H')->Unknown; echo $du;?></td>
                                            <td class=''><?php $dt=$sys->getStudentsTotalOverAll('200H')->Total; echo $dt;?></td>
                                            <td class=''><?php $dr=$sys->getStudentsTotalOverAll('200H')->Reg; echo $dr;?></td>
                                        </tr>
                                      <tr class="uk-table-middle">
                                            <td>Level 300 HND</td>
                                            <td class=''><?php $em=$sys->getStudentsTotalOverAll('300H')->Male; echo $em;?></td>
                                            <td class=''><?php $ef=$sys->getStudentsTotalOverAll('300H')->Female; echo $ef;?></td>
                                            <td class=''><?php $eu=$sys->getStudentsTotalOverAll('300H')->Unknown; echo $eu;?></td>
                                            <td class=''><?php $et=$sys->getStudentsTotalOverAll('300H')->Total; echo $et;?></td>
                                            <td class=''><?php $er=$sys->getStudentsTotalOverAll('300H')->Reg; echo $er;?></td>
                                        </tr>
                                   
                                         <tr class="uk-table-middle">
                                            <td>Level 100 BTECH TOP UP</td>
                                            <td class=''><?php $fm=$sys->getStudentsTotalOverAll('100BTT')->Male; echo $fm;?></td>
                                            <td class=''><?php $ff=$sys->getStudentsTotalOverAll('100BTT')->Female; echo $ff;?></td>
                                            <td class=''><?php $fu=$sys->getStudentsTotalOverAll('100BTT')->Unknown; echo $fu;?></td>
                                            <td class=''><?php $ft=$sys->getStudentsTotalOverAll('100BTT')->Total; echo $ft;?></td>
                                            <td class=''><?php $fr=$sys->getStudentsTotalOverAll('100BTT')->Reg; echo $fr;?></td>
                                        </tr>
                                          <tr class="uk-table-middle">
                                            <td>Level 200 BTECH TOP UP</td>
                                            <td class=''><?php $gm=$sys->getStudentsTotalOverAll('200BTT')->Male; echo $gm;?></td>
                                            <td class=''><?php $gf=$sys->getStudentsTotalOverAll('200BTT')->Female; echo $gf;?></td>
                                            <td class=''><?php $gu=$sys->getStudentsTotalOverAll('200BTT')->Unknown; echo $gu;?></td>
                                            <td class=''><?php $gt=$sys->getStudentsTotalOverAll('200BTT')->Total; echo $gt;?></td>
                                            <td class=''><?php $gr=$sys->getStudentsTotalOverAll('200BTT')->Reg; echo $gr;?></td>
                                        </tr>
                                        <tr class="uk-table-middle">
                                            <td>Level 100 MASTERS</td>
                                            <td class=''><?php $hm=$sys->getStudentsTotalOverAll('500MT')->Male; echo $hm;?></td>
                                            <td class=''><?php $hf=$sys->getStudentsTotalOverAll('500MT')->Female; echo $hf;?></td>
                                            <td class=''><?php $hu=$sys->getStudentsTotalOverAll('500MT')->Unknown; echo $hu;?></td>
                                            <td class=''><?php $ht=$sys->getStudentsTotalOverAll('500MT')->Total; echo $ht;?></td>
                                            <td class=''><?php $hr=$sys->getStudentsTotalOverAll('500MT')->Reg; echo $hr;?></td>
                                        </tr>
                                        <tr class="uk-table-middle">
                                            <td>Level 200 MASTERS</td>
                                            <td class=''><?php $im=$sys->getStudentsTotalOverAll('600MT')->Male; echo $im;?></td>
                                            <td class=''><?php $if=$sys->getStudentsTotalOverAll('600MT')->Female; echo $if;?></td>
                                            <td class=''><?php $iu=$sys->getStudentsTotalOverAll('600MT')->Unknown; echo $iu;?></td>
                                            <td class=''><?php $it=$sys->getStudentsTotalOverAll('600MT')->Total; echo $it;?></td>
                                            <td class=''><?php $ir=$sys->getStudentsTotalOverAll('600MT')->Reg; echo $ir;?></td>
                                        </tr>
                                        
                                        
                                        <tr>
                                            <td><p style="uk-text-bold">Total</p></td>
                                            <td><p style="uk-text-bold"><?php echo $am+$bm+$cm+$dm+$em+$fm+$gm+$hm+$im?>
                                            </p></td>
                                            <td><p style="uk-text-bold"><?php echo $bf+$bf+$cf+$df+$ef+$ff+$gf+$hf+$if?>
                                            </p></td>
                                            <td><p style="uk-text-bold"><?php echo $au+$bu+$cu+$du+$eu+$fu+$gu+$hu+$iu?>
                                            </p></td>
                                            <td><p style="uk-text-bold"><?php echo $at+$bt+$ct+$dt+$et+$ft+$gt+$ht+$it?>
                                            </p></td> 
                                            <td><p style="uk-text-bold"><?php echo $ar+$br+$cr+$dr+$er+$fr+$gr+$hr+$ir?>
                                            </p></td>                                          
                                        </tr>
                                        
                                    </tbody>
                                      
                                    </tbody>
                                </table>
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="uk-width-medium-1-2">
                    <div class="md-card">
                        <div class="md-card-content">
                            <h3 class="heading_a uk-margin-bottom">Statistics</h3>
                            <div id="ct-chart" class="chartist"></div>
                        </div>
                    </div>
                </div>
            </div>

          
@endsection
@section('js')
  <!-- d3 -->
        <script src="public/assets/plugins/d3/d3.min.js"></script>
        <!-- metrics graphics (charts) -->
        <script src="public/assets/plugins/metrics-graphics/dist/metricsgraphics.min.js"></script>
        <!-- chartist (charts) -->
        <script src="public/assets/plugins/chartist/dist/chartist.min.js"></script>
        <!-- maplace (google maps) -->
          <script src="public/assets/plugins/maplace-js/dist/maplace.min.js"></script>
        <!-- peity (small charts) -->
        <script src="public/assets/plugins/peity/jquery.peity.min.js"></script>
        <!-- easy-pie-chart (circular statistics) -->
        <script src="public/assets/plugins/jquery.easy-pie-chart/dist/jquery.easypiechart.min.js"></script>
        <!-- countUp -->
        <script src="public/assets/plugins/countUp.js/dist/countUp.min.js"></script>
        <!-- handlebars.js -->
        <script src="public/assets/plugins/handlebars/handlebars.min.js"></script>
        <script src="public/assets/js/custom/handlebars_helpers.min.js"></script>
        <!-- CLNDR -->
        <script src="public/assets/plugins/clndr/clndr.min.js"></script>
        <!-- fitvids -->
        <script src="public/assets/plugins/fitvids/jquery.fitvids.js"></script>

        <!--  dashbord functions -->
        <script src="public/assets/js/pages/dashboard.min.js"></script>
 
@endsection