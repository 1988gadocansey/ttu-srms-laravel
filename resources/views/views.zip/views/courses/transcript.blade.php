@extends('layouts.printlayout')

@section('content')
@inject('help', 'App\Http\Controllers\SystemController')
<div align="" style="margin-left: 12px">
<style>
    td{
        font-size: 13px
    }
   
        </style>
    <div class="md-card">
  
        <div   class="uk-grid" data-uk-grid-margin>

                <body>
                <div id="print">

                    <table  border="0" cellspacing="0" align="center">
                        <tr></tr>
                        <tr>
                            <th height="341" valign="top" class="bod" scope="row"><table width="100%" border="0">
                            <tr>
                                <th align="center" valign="middle" scope="row"><table width="882" height="113" border="0">
                                <tr>
                                    <th align="center" valign="middle" scope="row"><table style="" width="882" height="113" border="0" align="left">
                                    <tr>
                                        <td><img src='{{url("public/assets/img/printout.png")}}' style="width:581px;height:153px;margin-left: -5%;" /> </td

                                    </tr>
                                </table>
                                <table>
                                    <tr>
                                        <td align="center"><div class="" style="margin-left:-490px">DEPARTMENT: {{ strtoupper($help->getDepartmentName($help->getProgramDepartment($student->PROGRAMMECODE))) }}</div></td>
                                    </tr>
                                     <tr>
                                        <td align="center"><div class="" style="margin-left:-470px;text-align:">SCHOOL: {{ strtoupper($help->getSchoolName($help->getSchoolCode($help->getProgramDepartment($student->PROGRAMMECODE)))) }}</div></td>
                                    </tr>
                                    <tr>
                                        <td  ><div style="margin-left:11px"><hr>TRANSCRIPT - DRAFT</hr></div></td>
                                    </tr>

                                </table>
                                </tr>


                            </table>
                            <hr>
                            <div align="center">

                                <table border='0' class="uk-table" align="center"  width='900px'>
                                    <tr>
                                        <td width="" style="width:69%">
                                            <center>
                                                <table border='0' class="uk-table uk-table-nowrap uk-table-no-border" width=""  style="margin-left:-1%" >
                                                    <tbody><tr>
                                                            <td style="">NAME</td> <td style="padding-right: 36px;">{{$student->NAME}}</td>
                                                        </tr>

                                                        <tr>
                                                            <td style="padding-right: px;">INDEX NO</td> <td style="padding-right: 93px;">{{$student->INDEXNO}}</td>
                                                        </tr>

                                                        
                                                        

                                                        <tr>
                                                            <td>PROGRAMME</td> <td style="padding-right: 177px;"> {{strtoupper($student->program->PROGRAMME)}}</td>
                                                        </tr>



                                                    </tbody></table> </center>
                                        </td>
                                        <td width="15">&nbsp;             </td>
                                        
                                    </tr>
                                    </tr>
                                </table> <!-- end basic infos -->


                                <table class="uk-table uk-table-nowrap uk-table-hover" id=""> 
                                    <thead>
                                        <tr>

                                         <td  width="86" height="22" >Code</td>
                                          <td  width="558"><div>Title</div></td>
                                          <td  width="48"><div>CR</div></td>
                                          <td  width="49"><div>GR</div></td>
                                          <td width="95" ><div>GP</div> 
                                          <div align="center"></div>
                                          </td>



                                        </tr>
                                    </thead>
                                    <tbody>

                                        
                                        <tr align="">


 

                                        </tr>

                                        


                                    </tbody>

                                </table>
                                 
                                
                                 <div class="visible-print text-center" align='center'>
                                    {!! QrCode::size(100)->generate(Request::url()); !!}

                                </div>
                               
                            </div>
                              
</div>
                            </tr>
                        </table></th>
                        </tr>
                        <tr></tr>
                    </table>
                    
                    <div>
                    </div>
                </div>

        </div>


        @endsection

        @section('js')
        <script type="text/javascript">

         window.print();
 

        </script>

        @endsection