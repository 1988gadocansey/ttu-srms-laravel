<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\StudentModel;
use App\Models\ApplicantModel;
use App\Models;
use Yajra\Datatables\Datatables;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;
use Response;

class APIController extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    public function getStudentData(Request $request, $student)
    {
        header('Content-Type: application/json');

        $data = @Models\StudentModel::where("INDEXNO", $student)->orWhere("STNO", $student)->select("INDEXNO", "STNO", "NAME", "PROGRAMMECODE", "LEVEL", "BILLS", "STATUS")->first();
        if (empty($data)) {

            //return response()->json(array('data'=>"Student with index number $student does not exist."));
            $json = json_decode(file_get_contents("http://45.33.4.164/admissions/applicant/$student"), true, JSON_PRETTY_PRINT);

            $a[] = (array)$json;

            foreach ($a as $i) {
                $data["admission_number"] = $i["application_number"];
                $data["name"] = $i["name"];
                $data["programme"] = $i["programme"];
                $data["fees"] = $i["fees"];
                $data["hall"] = $i["hall"];
                $data["type"] = "Newly admited applicant";
            }


        }

        return response()->json(array('data' => $data));

    }

    public function fireVoucher(Request $request, SystemController $sys)
    {
        $data = Models\FormModel::where("PHONE", $request->input('phone'))->first();

        $pin = $data->serial;
        $serial = $data->PIN;
        $phone = $request->input('phone');
        $message = "Admission voucher: serial: $serial  pin code: $pin . Login at admissions.ttuportal.com Thanks";


        $sys->firesms($message, $phone, $phone);
        //return redirect("http://admissions.ttuportal.com");
        return redirect()->back();

    }

    public function getStudentProgram(Request $request, $program)
    {
        header('Content-Type: application/json');
        $indexno = $request->input("student");
        $data = @Models\StudentModel::where("PROGRAMMECODE", $program)->get();
        return response()->json(array('data' => $data));

    }

    public function getStudentHall(Request $request)
    {
        header('Content-Type: application/json');
        $indexno = $request->input("student");
        $data = @ApplicantModel::where("APPLICATION_NUMBER", $indexno)->first();
        if (!empty($data)) {
            return $data->HALL_ADMITTED;
        } else {
            return "Non Resident";
        }

    }


    public function qualityAssurance(Request $request, $indexno)
    {
        @StudentModel::where("INDEXNO", $indexno)->update(array("QUALITY_ASSURANCE" => 1));
        // return $this->response->json("status","Student Lecturer Assessment received at main system");
        return Response::json("Student Lecturer Assessment received at main system", "200");
    }

    public function liaison(Request $request, $indexno)
    {
        @ StudentModel::where("INDEXNO", $indexno)->update(array("LIAISON" => 1));
        return Response::json("Student Liaison forms received at main system", "200");
    }

    public function getReceipt()
    {
        \DB::beginTransaction();
        try {
            $receiptno_query = Models\ReceiptModel::first();
            $receiptno = date('Y') . str_pad($receiptno_query->no, 5, "0", STR_PAD_LEFT);
            \DB::commit();
            return $receiptno;
        } catch (\Exception $e) {
            \DB::rollback();
        }
    }

    public function updateReceipt()
    {
        \DB::beginTransaction();
        try {
            $query = Models\ReceiptModel::first();

            $result = $query->increment("no");
            if ($result) {
                \DB::commit();
            }
        } catch (\Exception $e) {
            \DB::rollback();
        }
    }

    public function payFeeLive(Request $request, SystemController $sys)
    {
        header('Content-Type: application/json');
        $bankAuth=["128ashbx393932","1nm383ypmwd123"];
        $indexno = $request->input("indexno");
        $amount = $request->input("amount");
        $bank = $request->input("accountNumber");
        $type = $request->input("fee_type");
        $transactionId = $request->input("transactionId");
        $date = $request->input("transactionDate");
        $auth= $request->input("auth");
        $array = $sys->getSemYear();
        $sem = $array[0]->SEMESTER;
        $year = $array[0]->YEAR;

        \DB::beginTransaction();
        try {

            if(in_array($auth,$bankAuth)) {

                $data = @StudentModel::where("INDEXNO", $indexno)->orWhere("STNO", $indexno)->first();

                $bankDetail = @Models\BankModel::where("ACCOUNT_NUMBER", $bank)->first();

                if ($bankDetail) {

                    if (!empty($data)) {

                        if (!empty($data)) {
                            // $bill = $sys->getYearBill($year, $data->LEVEL, $data->PROGRAMMECODE);
                            $billOwing = $data->BILL_OWING;
                            $owing = $billOwing - $amount;
                            if ($billOwing <= $amount) {
                                $details = "Full payment";


                            } else {
                                $details = "Part payment";
                            }
                            $paid = $data->PAID + $amount;
                            $que = Models\PortalPasswordModel::where("username", $indexno)->first();
                            if (empty($que) && !empty($indexno)) {
                                $program = $data->PROGRAMMECODE;
                                $str = 'abcdefhkmnprtuvwxy34678abcdefhkmnprtuvwxy34678';
                                $shuffled = str_shuffle($str);
                                $vcode = substr($shuffled, 0, 9);
                                $real = strtoupper($vcode);
                                $level = $data->LEVEL;
                                Models\PortalPasswordModel::create([
                                    'username' => $indexno,
                                    'real_password' => $real,
                                    'level' => $level,
                                    'programme' => $program,
                                    'biodata_update' => '1',
                                    'password' => bcrypt($real),
                                ]);
                                $phone = $data->TELEPHONENO;
                                $fname = $data->FIRSTNAME;

                                $message = "Online credential: visit records.ttuportal.com with $indexno as your username  and $real as password and follow the course registration steps.";


                                // @$sys->firesms($message, $phone, $indexno);

                                \DB::commit();

                            }

                            $receipt = $this->getReceipt();

                            $feeLedger = new Models\FeePaymentModel();
                            $feeLedger->INDEXNO = $indexno;
                            $feeLedger->PROGRAMME = $data->PROGRAMMECODE;
                            $feeLedger->AMOUNT = $amount;
                            $feeLedger->PAYMENTTYPE = $type;
                            $feeLedger->PAYMENTDETAILS = $details . " of " . $type;
                            $feeLedger->BANK_DATE = $date;

                            $feeLedger->LEVEL = $data->LEVEL;
                            $feeLedger->RECIEPIENT = "API_CALL";
                            $feeLedger->BANK = $bank;
                            $feeLedger->TRANSACTION_ID = $transactionId;
                            $feeLedger->RECEIPTNO = $receipt;
                            $feeLedger->YEAR = $year;
                            $feeLedger->FEE_TYPE = $type;
                            $feeLedger->SEMESTER = $sem;
                            if ($feeLedger->save()) {

                                @StudentModel::where("INDEXNO", $indexno)->orWhere("STNO", $indexno)->update(array("BILL_OWING" => $owing, "PAID" => $paid));
                                @$this->updateReceipt();
                                \DB::commit();
                                //return Response::json("Success", "01");
                                header('Content-Type: application/json');
                                // return  json_encode(array('responseCode'=>'01','responseMessage'=>'Successfully Processed'));
                                return response()->json(array('responseCode' => '01', 'responseMessage' => 'Successfully Processed'));

                            } else {
                                header('Content-Type: application/json');
                                // return  json_encode(array('responseCode'=>'09','responseMessage'=>'Failed'));
                                return response()->json(array('responseCode' => '09', 'responseMessage' => 'Failed'));
                            }

                        } else {

                            return response()->json(array('responseCode' => '09', 'responseMessage' => 'Student or Applicant does not exist'));

                        }


                    } else {

                        return response()->json(array('responseCode' => '09', 'responseMessage' => 'Student or Applicant does not exist'));

                    }


                } else {
                    return response()->json(array('responseCode' => '08', 'responseMessage' => 'Bank Account does not exist'));

                }
            }else{
                return response()->json(array('responseCode' => '08', 'responseMessage' => 'Unknown Bank Entity'));

            }
        }
        catch (\Exception $e) {
            \DB::rollback();
        }

    }


    public function payFee(Request $request, SystemController $sys)
    {
        header('Content-Type: application/json');
        $bankAuth=["128ashbx393932","1nm383ypmwd123"];
        $indexno = $request->input("indexno");
        $amount = $request->input("amount");
        $bank = $request->input("accountNumber");
        $type = $request->input("fee_type");
        $transactionId = $request->input("transactionId");
        $date = $request->input("transactionDate");
        $auth= $request->input("auth");
        $array = $sys->getSemYear();
        $sem = $array[0]->SEMESTER;
        $year = $array[0]->YEAR;

        \DB::beginTransaction();
        try {

            $data = @StudentModel::where("INDEXNO", $indexno)->orWhere("STNO", $indexno)->first();

            $bankDetail = @Models\BankModel::where("ACCOUNT_NUMBER", $bank)->first();

            if ($bankDetail) {

                if (!empty($data)) {

                    if (!empty($data)) {
                        // $bill = $sys->getYearBill($year, $data->LEVEL, $data->PROGRAMMECODE);
                        $billOwing = $data->BILL_OWING ;
                        $owing = $billOwing - $amount;
                        if ($billOwing <= $amount) {
                            $details = "Full payment";


                        } else {
                            $details = "Part payment";
                        }
                        $paid=$data->PAID + $amount;
                        $que = Models\PortalPasswordModel::where("username", $indexno)->first();
                        if (empty($que) && !empty($indexno)) {
                            $program = $data->PROGRAMMECODE;
                            $str = 'abcdefhkmnprtuvwxy34678abcdefhkmnprtuvwxy34678';
                            $shuffled = str_shuffle($str);
                            $vcode = substr($shuffled, 0, 9);
                            $real = strtoupper($vcode);
                            $level = $data->LEVEL;
                            Models\PortalPasswordModel::create([
                                'username' => $indexno,
                                'real_password' => $real,
                                'level' => $level,
                                'programme' => $program,
                                'biodata_update' => '1',
                                'password' => bcrypt($real),
                            ]);
                            $phone = $data->TELEPHONENO;
                            $fname = $data->FIRSTNAME;

                            $message = "Online credential: visit records.ttuportal.com with $indexno as your username  and $real as password and follow the course registration steps.";


                            // @$sys->firesms($message, $phone, $indexno);

                            \DB::commit();

                        }

                        $receipt = $this->getReceipt();

                        $feeLedger = new Models\FeePaymentModel();
                        $feeLedger->INDEXNO = $indexno;
                        $feeLedger->PROGRAMME = $data->PROGRAMMECODE;
                        $feeLedger->AMOUNT = $amount;
                        $feeLedger->PAYMENTTYPE = $type;
                        $feeLedger->PAYMENTDETAILS = $details . " of " . $type;
                        $feeLedger->BANK_DATE = $date;

                        $feeLedger->LEVEL = $data->LEVEL;
                        $feeLedger->RECIEPIENT = "API_CALL";
                        $feeLedger->BANK = $bank;
                        $feeLedger->TRANSACTION_ID = $transactionId;
                        $feeLedger->RECEIPTNO = $receipt;
                        $feeLedger->YEAR = $year;
                        $feeLedger->FEE_TYPE = $type;
                        $feeLedger->SEMESTER = $sem;
                        if ($feeLedger->save()) {

                            @StudentModel::where("INDEXNO", $indexno)->orWhere("STNO", $indexno)->update(array("BILL_OWING" => $owing,  "PAID"=>$paid));
                            @$this->updateReceipt();
                            \DB::commit();
                            //return Response::json("Success", "01");
                            header('Content-Type: application/json');
                            // return  json_encode(array('responseCode'=>'01','responseMessage'=>'Successfully Processed'));
                            return response()->json(array('responseCode' => '01', 'responseMessage' => 'Successfully Processed'));

                        } else {
                            header('Content-Type: application/json');
                            // return  json_encode(array('responseCode'=>'09','responseMessage'=>'Failed'));
                            return response()->json(array('responseCode' => '09', 'responseMessage' => 'Failed'));
                        }

                    } else {

                        return response()->json(array('responseCode' => '09', 'responseMessage' => 'Student or Applicant does not exist'));

                    }



                }
                else{

                    return response()->json(array('responseCode' => '09', 'responseMessage' => 'Student or Applicant does not exist'));

                }




            } else {
                return response()->json(array('responseCode' => '08', 'responseMessage' => 'Bank Account does not exist'));

            }
        }
        catch (\Exception $e) {
            \DB::rollback();
        }


    }


    /**
     * Destroy the given task.
     *
     * @param  Request $request
     * @param  Task $task
     * @return Response
     */
    public function destroy(Request $request, Task $task)
    {
        $this->authorize('destroy', $task);

        $task->delete();

        return redirect('/tasks');
    }

}
