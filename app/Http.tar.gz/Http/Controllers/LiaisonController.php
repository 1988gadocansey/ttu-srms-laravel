<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models;

use Yajra\Datatables\Datatables;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;

class LiaisonController extends Controller
{

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');


    }

    public function log_query()
    {
        \DB::listen(function ($sql, $binding, $timing) {
            \Log::info('showing query', array('sql' => $sql, 'bindings' => $binding));
        }
        );
    }



    /**
     * Display a list of all of the user's task.
     *
     * @param  Request $request
     * @return Response
     */

    public function index(Request $request, SystemController $sys) {



             $data =Models\LiaisonModel::query();




        if ($request->has('program') && trim($request->input('program')) != "") {
            $data->whereHas('studentDetials', function($q)use ($request) {
                $q->whereHas('programme', function($q)use ($request) {
                    $q->whereIn('PROGRAMMECODE', [$request->input('program')]);
                });
            });
        }








        if ($request->has('level') && trim($request->input('level')) != "") {
            $data->where("level", $request->input("level", ""));
        }

        if ($request->has('year') && trim($request->input('year')) != "") {
            $data->where("year", $request->input("year", ""));
        }


        if ($request->has('search') && trim($request->input('search')) != "" && trim($request->input('by')) != "") {
            // dd($request);
            $data->where($request->input('by'), "LIKE", "%" . $request->input("search", "") . "%")
            ;
        }


        $records = $data->orderBy('year')->orderBy('terms')->paginate(200);


        $request->flashExcept("_token");

        \Session::put('students', $records);
        //dd($records);
        return view('liaison.index')->with("records", $records)
            ->with('year', $sys->years())
            ->with('nationality', $sys->getCountry())
            ->with('halls', $sys->getHalls())
            ->with('level', $sys->getLevelList())
            ->with('religion', $sys->getReligion())
            ->with('region', $sys->getRegions())
            ->with('department', $sys->getDepartmentList())
            ->with('school', $sys->getSchoolList())
            ->with('programme', $sys->getProgramList())
            ->with('type', $sys->getProgrammeTypes());

    }

}
